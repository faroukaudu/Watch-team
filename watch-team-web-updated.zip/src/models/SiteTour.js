const mongoose = require("mongoose");

const siteTourCheckpointSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    description: String,
    qrCodeValue: {
      type: String,
      required: true,
    },
    order: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { _id: true }
);

const siteTourProgressSchema = new mongoose.Schema(
  {
    guardId: String,
    guardName: String,
    startedAt: Date,
    completedAt: Date,
    status: {
      type: String,
      enum: ["Not Started", "In Progress", "Completed"],
      default: "Not Started",
    },
    scannedCheckpoints: [
      {
        checkpointId: String,
        checkpointName: String,
        scannedAt: Date,
        qrCodeValue: String,
        latitude: String,
        longitude: String,
      },
    ],
  },
  { _id: true }
);

const siteTourSchema = new mongoose.Schema(
  {
    companyId: {
      type: String,
      required: true,
    },
    postSiteId: {
      type: String,
      required: true,
    },
    postSiteName: String,

    tourName: {
      type: String,
      required: true,
      trim: true,
    },
    description: String,

    createdById: String,
    createdByName: String,
    createdByUserType: String,

    checkpoints: [siteTourCheckpointSchema],

    progress: [siteTourProgressSchema],

    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("SiteTour", siteTourSchema);
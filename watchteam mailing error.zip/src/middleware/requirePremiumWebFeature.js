const UserSubscription = require("../models/UserSubscription");
const {
  requirePlanUpgrade,
  requireClientCompanyUpgrade,
} = require("../utils/accessResponse");

function normalize(value = "") {
  return String(value).trim().toLowerCase();
}

function isAdvancedOrProfessional(planCode = "") {
  const code = normalize(planCode);
  return code.includes("advanced") || code.includes("professional");
}

function wantsJson(req) {
  return Boolean(
    req.xhr ||
    String(req.headers.accept || "").includes("application/json") ||
    req.path.startsWith("/api/")
  );
}

async function findActiveCompanySubscription(req) {
  if (req.userSubscription) return req.userSubscription;

  const companyId = String(req.user?.assignedCompanyID || "").trim();
  if (!companyId) return null;

  return UserSubscription.findOne({
    companyId,
    isActive: true,
    subscriptionStatus: { $in: ["active", "trialing"] },
    $or: [
      { expiresAt: null },
      { expiresAt: { $exists: false } },
      { expiresAt: { $gte: new Date() } },
    ],
  })
    .sort({ createdAt: -1 })
    .lean();
}

function requirePremiumWebFeature(featureName) {
  return async function premiumWebFeatureMiddleware(req, res, next) {
    try {
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        if (wantsJson(req)) {
          return res.status(401).json({ ok: false, message: "Authentication required." });
        }
        return res.redirect("/sign-in");
      }

      const userType = String(req.user?.userType || "").trim();

      // Platform Admin bypasses plan restrictions.
      if (userType === "Platform Admin") return next();

      // Client access inherits the active subscription of the company/Super Admin.
      const subscription = await findActiveCompanySubscription(req);
      const hasPremiumAccess =
        subscription && isAdvancedOrProfessional(subscription.planCode || subscription.planName);

      if (!hasPremiumAccess) {
        if (wantsJson(req)) {
          return res.status(403).json({
            ok: false,
            type: "upgrade",
            message:
              userType === "Client"
                ? `${featureName} is not included in your company’s current plan. Please contact your administrator to upgrade to Advanced or Professional.`
                : `Your current plan does not include ${featureName}. Upgrade to Advanced or Professional to continue.`,
          });
        }

        return userType === "Client"
          ? requireClientCompanyUpgrade(req, res, featureName)
          : requirePlanUpgrade(req, res, featureName);
      }

      req.userSubscription = subscription;
      res.locals.userSubscription = subscription;
      return next();
    } catch (error) {
      console.error(`${featureName} access check error:`, error);
      if (wantsJson(req)) {
        return res.status(500).json({ ok: false, message: `Unable to verify access to ${featureName}.` });
      }
      return res.status(500).send(`Unable to verify access to ${featureName}.`);
    }
  };
}

module.exports = {
  requirePremiumWebFeature,
  isAdvancedOrProfessional,
};

const nodemailer = require("nodemailer");

/**
 * Send an application email and resolve only after the SMTP provider
 * confirms that the message was accepted. Existing callers can continue
 * using the same argument structure.
 */
async function emailSent({
  sendTo: to,
  title: subject,
  message: text,
  template: html,
}) {
  const transporter = nodemailer.createTransport({
    host: "localhost",
    service: "gmail",
    tls: {
      rejectUnauthorized: true,
      servername: "gmail.com",
    },
    auth: {
      user:
        process.env.WATCHTEAM_EMAIL_USER ||
        "surerealintegratedserviceltd@gmail.com",
      pass: process.env.WATCHTEAM_EMAIL_PASSWORD || "vvheoqjyhbksmffr",
    },
  });

  const info = await transporter.sendMail({
    from:
      process.env.WATCHTEAM_EMAIL_FROM ||
      "Watch Team Security <noreply.watchteam@gmail.com>",
    replyTo:
      process.env.WATCHTEAM_EMAIL_REPLY_TO ||
      "noreply.watchteam@gmail.com",
    to,
    subject,
    text,
    html,
  });

  console.log("Email accepted by SMTP provider:", info.messageId);
  return info;
}

module.exports = { emailSent };
